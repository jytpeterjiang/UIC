﻿_Bool isDigitChar(char c);
